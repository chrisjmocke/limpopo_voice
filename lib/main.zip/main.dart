import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const LimpopoVoiceApp());
}

class LimpopoVoiceApp extends StatelessWidget {
  const LimpopoVoiceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LimpopoHome(),
    );
  }
}

class LimpopoHome extends StatefulWidget {
  const LimpopoHome({super.key});

  @override
  State<LimpopoHome> createState() => _LimpopoHomeState();
}

class _LimpopoHomeState extends State<LimpopoHome> {
  final FlutterTts _tts = FlutterTts();
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  final TextEditingController _textController = TextEditingController();

  int credits = 0;
  bool recording = false;

  String originalText = "";
  String translatedText = "";
  String errorMessage = "";

  final Map<String, String> languageCodes = {
    "English": "en",
    "Sepedi": "nso",
    "Xitsonga": "ts",
    "Tshivenda": "ve",
    "Afrikaans": "af",
  };

  String sourceLanguage = "English";
  String targetLanguage = "Sepedi";

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await FirebaseAuth.instance.signInAnonymously();
    await Permission.microphone.request();
    await _recorder.openRecorder();
    await _loadUser();
  }

  Future<void> _loadUser() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final doc =
        await FirebaseFirestore.instance.collection("users").doc(uid).get();

    setState(() {
      credits = doc.data()?['credits'] ?? 0;
    });
  }

  Future<void> _processTranslation({Uint8List? audio, String? text}) async {
    try {
      final callable = FirebaseFunctions.instanceFor(
        region: 'africa-south1',
      ).httpsCallable('processSpeech');

      final result = await callable.call({
        if (audio != null) "audio": base64Encode(audio),
        if (text != null) "text": text,
        "sourceLanguage": languageCodes[sourceLanguage],
        "targetLanguage": languageCodes[targetLanguage],
      });

      setState(() {
        credits = result.data['remainingCredits'] ?? credits;
        originalText = result.data['originalText'] ?? text ?? "";
        translatedText = result.data['translatedText'] ?? "";
        errorMessage = "";
      });

      await FirebaseFirestore.instance
          .collection("users")
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .collection("history")
          .add({
        "original": originalText,
        "translated": translatedText,
        "timestamp": Timestamp.now()
      });

      await _tts.setLanguage(languageCodes[targetLanguage]!);
      await _tts.speak(translatedText);

    } catch (e) {
      setState(() {
        errorMessage = e.toString();
      });
    }
  }

  Future<void> _startRecording() async {
    if (_recorder.isRecording) return;

    setState(() => recording = true);

    await _recorder.startRecorder(
      codec: Codec.pcm16,
      sampleRate: 16000,
      numChannels: 1,
    );
  }

  Future<void> _stopRecording() async {
    if (!_recorder.isRecording) return;

    final path = await _recorder.stopRecorder();
    setState(() => recording = false);

    if (path != null) {
      // fallback: use text if audio pipeline fails
      await _processTranslation(text: "Voice captured");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [

          Positioned.fill(
            child: Image.asset(
              'assets/limpopo_voice.png',
              fit: BoxFit.cover,
            ),
          ),

          SafeArea(
            child: Column(
              children: [

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Credits: $credits",
                        style: const TextStyle(color: Colors.white)),
                    const Text("Limpopo Voice",
                        style: TextStyle(color: Colors.white, fontSize: 18)),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const HistoryPage(),
                          ),
                        );
                      },
                      child: const Text("History",
                          style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                GestureDetector(
                  onLongPressStart: (_) => _startRecording(),
                  onLongPressEnd: (_) => _stopRecording(),
                  child: Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      color: recording ? Colors.red : Colors.green,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Text("TALK",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20)),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                if (originalText.isNotEmpty)
                  Text(originalText,
                      style: const TextStyle(color: Colors.white)),

                if (translatedText.isNotEmpty)
                  Text(translatedText,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold)),

                Padding(
                  padding: const EdgeInsets.all(12),
                  child: TextField(
                    controller: _textController,
                    decoration: const InputDecoration(
                      hintText: "Insert text",
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ),

                ElevatedButton(
                  onPressed: () =>
                      _processTranslation(text: _textController.text),
                  child: const Text("Translate"),
                ),

                if (errorMessage.isNotEmpty)
                  Text(errorMessage,
                      style: const TextStyle(color: Colors.red)),

                const Spacer(),

                Align(
                  alignment: Alignment.bottomRight,
                  child: IconButton(
                    icon: const Icon(Icons.share, color: Colors.white),
                    onPressed: () {
                      Share.share(
                          "Download Limpopo Voice: https://yourapp.link");
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: const Text("History")),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection("users")
            .doc(uid)
            .collection("history")
            .orderBy("timestamp", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          return ListView(
            children: docs
                .map((d) => ListTile(
                      title: Text(d['translated']),
                      subtitle: Text(d['original']),
                    ))
                .toList(),
          );
        },
      ),
    );
  }
}